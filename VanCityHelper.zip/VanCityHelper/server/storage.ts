import { 
  users, 
  User, 
  InsertUser, 
  locations, 
  Location, 
  InsertLocation,
  reviews,
  Review,
  InsertReview,
  categories,
  Category,
  InsertCategory
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPremium(id: number, isPremium: boolean): User;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  
  // Location operations
  getLocations(): Promise<Location[]>;
  getLocation(id: number): Promise<Location | undefined>;
  getLocationsByCategory(category: string): Promise<Location[]>;
  getLocationsByUser(userId: number): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  updateLocation(id: number, location: Partial<Location>): Location;
  deleteLocation(id: number): void;
  
  // Review operations
  getReviewsByLocation(locationId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Session store
  sessionStore: any; // Using any to avoid type issues
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private locations: Map<number, Location>;
  private reviews: Map<number, Review>;
  private categories: Map<number, Category>;
  sessionStore: any; // Using any to avoid type issues
  
  private userIdCounter: number;
  private locationIdCounter: number;
  private reviewIdCounter: number;
  private categoryIdCounter: number;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.reviews = new Map();
    this.categories = new Map();
    
    this.userIdCounter = 1;
    this.locationIdCounter = 1;
    this.reviewIdCounter = 1;
    this.categoryIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Add default categories
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Add default categories
    const defaultCategories: InsertCategory[] = [
      { name: "Eczaneler", icon: "local_pharmacy", color: "#1E40AF" },
      { name: "Taksi Durakları", icon: "local_taxi", color: "#EAB308" },
      { name: "Restaurantlar", icon: "restaurant", color: "#EF4444" },
      { name: "Oteller", icon: "hotel", color: "#8B5CF6" },
      { name: "Marketler", icon: "shopping_basket", color: "#10B981" },
      { name: "Turistik Yerler", icon: "attractions", color: "#3B82F6" }
    ];
    
    defaultCategories.forEach(category => {
      this.createCategory(category);
    });
    
    // Create admin user
    this.createUser({
      username: "admin",
      password: "admin123.salt", // This would normally be hashed
      fullName: "Admin User",
      email: "admin@vanrehberi.com",
    }).then(user => {
      const adminUser = { ...user, isAdmin: true };
      this.users.set(user.id, adminUser);
      
      // Add sample locations for Van
      const sampleLocations: InsertLocation[] = [
        {
          name: "Akdamar Eczanesi",
          category: "Eczaneler",
          address: "Cumhuriyet Cad. No:15, Van Merkez",
          phone: "0432 123 45 67",
          description: "7/24 nöbetçi eczane hizmeti",
          hours: "08:00-23:00",
          latitude: "38.499",
          longitude: "43.385",
          images: ["pharmacy1.jpg"],
          userId: adminUser.id,
          isPremium: true
        },
        {
          name: "Van Gölü Taksi",
          category: "Taksi Durakları",
          address: "İskele Mah. No:5, Van Merkez",
          phone: "0432 234 56 78",
          description: "7/24 taksi hizmeti",
          hours: "00:00-23:59",
          latitude: "38.503",
          longitude: "43.389",
          images: ["taxi1.jpg"],
          userId: adminUser.id,
          isPremium: false
        },
        {
          name: "Karahan Restoran",
          category: "Restaurantlar",
          address: "İpekyolu Cad. No:45, Van Merkez",
          phone: "0432 345 67 89",
          description: "Geleneksel Van kahvaltısı ve yöresel lezzetler",
          hours: "07:00-22:00",
          latitude: "38.495",
          longitude: "43.375",
          images: ["restaurant1.jpg", "restaurant2.jpg"],
          userId: adminUser.id,
          isPremium: true
        },
        {
          name: "Elite World Van Hotel",
          category: "Oteller",
          address: "Ipek Yolu Üzeri, Van Merkez",
          phone: "0432 456 78 90",
          description: "5 yıldızlı otel, Van Gölü manzaralı",
          hours: "Check-in: 14:00, Check-out: 12:00",
          latitude: "38.510",
          longitude: "43.380",
          images: ["hotel1.jpg", "hotel2.jpg"],
          userId: adminUser.id,
          isPremium: true
        },
        {
          name: "Van Market",
          category: "Marketler",
          address: "Bahçıvan Mah. No:23, Van Merkez",
          phone: "0432 567 89 01",
          description: "Yerel ürünler ve Van otlu peyniri",
          hours: "08:00-22:00",
          latitude: "38.492",
          longitude: "43.372",
          images: ["market1.jpg"],
          userId: adminUser.id,
          isPremium: false
        },
        {
          name: "Akdamar Adası",
          category: "Turistik Yerler",
          address: "Gevaş, Van",
          phone: "0432 678 90 12",
          description: "Akdamar Kilisesi ve tarihi ada turu",
          hours: "09:00-18:00",
          latitude: "38.340",
          longitude: "43.036",
          images: ["akdamar1.jpg", "akdamar2.jpg"],
          userId: adminUser.id,
          isPremium: true
        },
        {
          name: "Van Kalesi",
          category: "Turistik Yerler",
          address: "Van Kalesi, Van Merkez",
          phone: "0432 789 01 23",
          description: "Urartu döneminden kalma tarihi kale",
          hours: "09:00-17:00",
          latitude: "38.507",
          longitude: "43.339",
          images: ["castle1.jpg"],
          userId: adminUser.id,
          isPremium: false
        },
        {
          name: "Muradiye Şelalesi",
          category: "Turistik Yerler",
          address: "Muradiye, Van",
          phone: "0432 890 12 34",
          description: "Doğal güzelliği ile ünlü şelale",
          hours: "Her zaman açık",
          latitude: "38.987",
          longitude: "43.764",
          images: ["waterfall1.jpg"],
          userId: adminUser.id,
          isPremium: false
        }
      ];
      
      // Add each location and set as approved
      sampleLocations.forEach(loc => {
        this.createLocation(loc).then(location => {
          this.updateLocation(location.id, { isApproved: true });
        });
      });
      
      // Add some reviews for the locations
      setTimeout(() => {
        this.createReview({
          userId: adminUser.id,
          locationId: 1, // Akdamar Eczanesi
          rating: 5,
          comment: "Çok ilgili personel, her zaman ihtiyacım olan ilaçları bulabiliyorum."
        });
        
        this.createReview({
          userId: adminUser.id,
          locationId: 3, // Karahan Restoran
          rating: 4,
          comment: "Van kahvaltısı harika. Kesinlikle denenmeli."
        });
        
        this.createReview({
          userId: adminUser.id,
          locationId: 6, // Akdamar Adası
          rating: 5,
          comment: "Muhteşem manzara ve tarihi doku. Van'a gelince kesinlikle görülmeli."
        });
      }, 500);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = {
      ...insertUser,
      id,
      isPremium: false,
      isAdmin: false,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  updateUserPremium(id: number, isPremium: boolean): User {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, isPremium };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUser(id: number, updateData: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, ...updateData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Location operations
  async getLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async getLocationsByCategory(category: string): Promise<Location[]> {
    return Array.from(this.locations.values()).filter(
      (location) => location.category === category && location.isApproved,
    );
  }

  async getLocationsByUser(userId: number): Promise<Location[]> {
    return Array.from(this.locations.values()).filter(
      (location) => location.userId === userId,
    );
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.locationIdCounter++;
    const now = new Date();
    const location: Location = {
      ...insertLocation,
      id,
      isApproved: false,
      createdAt: now
    };
    this.locations.set(id, location);
    return location;
  }

  updateLocation(id: number, updateData: Partial<Location>): Location {
    const location = this.locations.get(id);
    if (!location) {
      throw new Error("Location not found");
    }
    
    const updatedLocation = { ...location, ...updateData };
    this.locations.set(id, updatedLocation);
    return updatedLocation;
  }

  deleteLocation(id: number): void {
    this.locations.delete(id);
  }

  // Review operations
  async getReviewsByLocation(locationId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.locationId === locationId,
    );
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const now = new Date();
    const review: Review = {
      ...insertReview,
      id,
      createdAt: now
    };
    this.reviews.set(id, review);
    return review;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = {
      ...insertCategory,
      id
    };
    this.categories.set(id, category);
    return category;
  }
}

export const storage = new MemStorage();
