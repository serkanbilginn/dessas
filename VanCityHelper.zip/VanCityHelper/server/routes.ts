import type { Express } from "express";
import { createServer, type Server } from "http";
import passport from "passport";
import { storage } from "./storage";
import { setupAuth, hashPassword, comparePasswords } from "./auth";
import { insertLocationSchema, insertReviewSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // API routes
  
  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Kategoriler yüklenirken bir hata oluştu" });
    }
  });
  
  // Locations
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getLocations();
      // Only return approved locations unless admin
      let filteredLocations = locations.filter(loc => loc.isApproved);
      
      // If user is admin, include unapproved
      if (req.isAuthenticated() && req.user.isAdmin) {
        filteredLocations = locations;
      }
      
      res.json(filteredLocations);
    } catch (error) {
      res.status(500).json({ message: "Mekanlar yüklenirken bir hata oluştu" });
    }
  });
  
  app.get("/api/locations/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const locations = await storage.getLocationsByCategory(category);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Mekanlar yüklenirken bir hata oluştu" });
    }
  });
  
  app.get("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      
      if (!location) {
        return res.status(404).json({ message: "Mekan bulunamadı" });
      }
      
      // If location is not approved and user is not admin, return 403
      if (!location.isApproved && !(req.isAuthenticated() && req.user.isAdmin)) {
        return res.status(403).json({ message: "Bu mekana erişim izniniz yok" });
      }
      
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Mekan bilgisi yüklenirken bir hata oluştu" });
    }
  });
  
  app.post("/api/locations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Bu işlem için giriş yapmalısınız" });
    }
    
    try {
      // Validate the request body
      const validatedData = insertLocationSchema.parse(req.body);
      
      // Check if user is premium for premium listings
      if (validatedData.isPremium && !req.user.isPremium) {
        return res.status(403).json({ message: "Premium mekan eklemek için premium üye olmalısınız" });
      }
      
      // Set the user ID
      validatedData.userId = req.user.id;
      
      // If user is admin or premium, auto-approve
      if (req.user.isAdmin || req.user.isPremium) {
        validatedData.isApproved = true;
      }
      
      const location = await storage.createLocation(validatedData);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ message: "Mekan eklenirken bir hata oluştu" });
    }
  });
  
  app.put("/api/locations/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Bu işlem için giriş yapmalısınız" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      
      if (!location) {
        return res.status(404).json({ message: "Mekan bulunamadı" });
      }
      
      // Check if user owns this location or is admin
      if (location.userId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Bu mekanı düzenleme yetkiniz yok" });
      }
      
      const updatedLocation = storage.updateLocation(id, req.body);
      res.json(updatedLocation);
    } catch (error) {
      res.status(400).json({ message: "Mekan güncellenirken bir hata oluştu" });
    }
  });
  
  app.delete("/api/locations/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Bu işlem için giriş yapmalısınız" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      
      if (!location) {
        return res.status(404).json({ message: "Mekan bulunamadı" });
      }
      
      // Check if user owns this location or is admin
      if (location.userId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Bu mekanı silme yetkiniz yok" });
      }
      
      storage.deleteLocation(id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ message: "Mekan silinirken bir hata oluştu" });
    }
  });
  
  // Admin routes
  app.put("/api/admin/locations/:id/approve", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Bu işlem için admin yetkileri gerekiyor" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      
      if (!location) {
        return res.status(404).json({ message: "Mekan bulunamadı" });
      }
      
      const updatedLocation = storage.updateLocation(id, { isApproved: true });
      res.json(updatedLocation);
    } catch (error) {
      res.status(400).json({ message: "Mekan onaylanırken bir hata oluştu" });
    }
  });
  
  // Reviews
  app.get("/api/locations/:id/reviews", async (req, res) => {
    try {
      const locationId = parseInt(req.params.id);
      const reviews = await storage.getReviewsByLocation(locationId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Değerlendirmeler yüklenirken bir hata oluştu" });
    }
  });
  
  app.post("/api/locations/:id/reviews", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Bu işlem için giriş yapmalısınız" });
    }
    
    try {
      const locationId = parseInt(req.params.id);
      const location = await storage.getLocation(locationId);
      
      if (!location) {
        return res.status(404).json({ message: "Mekan bulunamadı" });
      }
      
      // Validate the request body
      const validatedData = insertReviewSchema.parse({
        ...req.body,
        userId: req.user.id,
        locationId
      });
      
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      res.status(400).json({ message: "Değerlendirme eklenirken bir hata oluştu" });
    }
  });
  
  // My locations (for users)
  app.get("/api/my/locations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Bu işlem için giriş yapmalısınız" });
    }
    
    try {
      const locations = await storage.getLocationsByUser(req.user.id);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Mekanlarınız yüklenirken bir hata oluştu" });
    }
  });
  
  // User routes
  app.get("/api/user", passport.authenticate("session"), (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // @ts-ignore - exclude password for security
    const { password, ...user } = req.user;
    
    res.json(user);
  });
  
  // Update user profile
  app.put("/api/user/profile", passport.authenticate("session"), async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { fullName, email } = req.body;
      
      if (!fullName || !email) {
        return res.status(400).json({ message: "Ad soyad ve e-posta alanları zorunludur" });
      }
      
      // Check if email is already taken by another user
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser && existingUser.id !== req.user.id) {
        return res.status(400).json({ message: "Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor" });
      }
      
      // @ts-ignore
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Update user
      const updatedUser = {
        ...user,
        fullName,
        email
      };
      
      // @ts-ignore - Storage implementation handles this
      await storage.updateUser(userId, updatedUser);
      
      // Return the updated user without password
      const { password, ...userData } = updatedUser;
      res.json(userData);
    } catch (error) {
      console.error("Profile update error:", error);
      res.status(500).json({ message: "Profil güncellenirken bir hata oluştu" });
    }
  });
  
  // Update user password
  app.put("/api/user/password", passport.authenticate("session"), async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Mevcut şifre ve yeni şifre alanları zorunludur" });
      }
      
      // @ts-ignore
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Verify current password
      const isPasswordValid = await comparePasswords(currentPassword, user.password);
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Mevcut şifre yanlış" });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update user
      const updatedUser = {
        ...user,
        password: hashedPassword
      };
      
      // @ts-ignore - Storage implementation handles this
      await storage.updateUser(userId, updatedUser);
      
      res.json({ message: "Şifre başarıyla değiştirildi" });
    } catch (error) {
      console.error("Password update error:", error);
      res.status(500).json({ message: "Şifre değiştirilirken bir hata oluştu" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
