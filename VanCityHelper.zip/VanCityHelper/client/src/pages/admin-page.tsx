import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/ui/layout/header";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Eye, Check, X, AlertTriangle } from "lucide-react";
import { Location, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function AdminPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("locations");
  
  // Fetch all locations including unapproved ones
  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
  });
  
  // Count unapproved locations
  const unapprovedLocations = locations.filter(loc => !loc.isApproved);
  
  // Approve location mutation
  const approveMutation = useMutation({
    mutationFn: async (locationId: number) => {
      const res = await apiRequest("PUT", `/api/admin/locations/${locationId}/approve`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/locations"] });
      toast({
        title: "Mekan onaylandı",
        description: "Mekan başarıyla onaylandı ve listelenmeye başlandı.",
      });
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Mekan onaylanırken bir hata oluştu: " + error.message,
        variant: "destructive",
      });
    }
  });
  
  const approveLocation = (locationId: number) => {
    approveMutation.mutate(locationId);
  };
  
  const formatDate = (date: Date) => {
    try {
      return format(new Date(date), 'dd.MM.yyyy HH:mm');
    } catch (e) {
      return 'Geçersiz tarih';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <Card className="mb-8">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl font-bold">Admin Paneli</CardTitle>
            <CardDescription>
              Van Rehberi uygulamasını buradan yönetebilirsiniz.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-blue-50">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold text-primary">{locations.length}</div>
                  <div className="text-sm text-muted-foreground">Toplam Mekan</div>
                </CardContent>
              </Card>
              <Card className="bg-yellow-50">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold text-yellow-600">{unapprovedLocations.length}</div>
                  <div className="text-sm text-muted-foreground">Onay Bekleyen Mekan</div>
                </CardContent>
              </Card>
              <Card className="bg-green-50">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold text-green-600">
                    {locations.filter(loc => loc.isPremium).length}
                  </div>
                  <div className="text-sm text-muted-foreground">Premium Mekan</div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="locations" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="locations">Mekanlar</TabsTrigger>
            <TabsTrigger value="users">Kullanıcılar</TabsTrigger>
            <TabsTrigger value="reports">Raporlar</TabsTrigger>
          </TabsList>
          
          <TabsContent value="locations">
            <Card>
              <CardHeader>
                <CardTitle>Mekan Yönetimi</CardTitle>
                <CardDescription>
                  Tüm mekanları görüntüleyin, onaylayın veya kaldırın.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Mekan Adı</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Oluşturulma Tarihi</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {locations.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-6">
                          <AlertTriangle className="mx-auto h-8 w-8 mb-2" />
                          <p>Henüz hiç mekan eklenmemiş.</p>
                        </TableCell>
                      </TableRow>
                    ) : (
                      locations.map((location) => (
                        <TableRow key={location.id}>
                          <TableCell>{location.id}</TableCell>
                          <TableCell className="font-medium">{location.name}</TableCell>
                          <TableCell>{location.category}</TableCell>
                          <TableCell>{formatDate(location.createdAt)}</TableCell>
                          <TableCell>
                            {location.isApproved ? (
                              <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                                Onaylandı
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">
                                Onay Bekliyor
                              </Badge>
                            )}
                            {location.isPremium && (
                              <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-600 border-blue-200">
                                Premium
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              {!location.isApproved && (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="text-green-600"
                                  onClick={() => approveLocation(location.id)}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                              )}
                              <Button variant="outline" size="sm" className="text-red-600">
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Kullanıcı Yönetimi</CardTitle>
                <CardDescription>
                  Kullanıcıları yönetin ve premium durumlarını kontrol edin.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-8 text-center text-muted-foreground">
                  <AlertTriangle className="mx-auto h-8 w-8 mb-2" />
                  <p>Bu bölüm şu anda geliştirme aşamasındadır.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Raporlar</CardTitle>
                <CardDescription>
                  Uygulama kullanım istatistiklerini görüntüleyin.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-8 text-center text-muted-foreground">
                  <AlertTriangle className="mx-auto h-8 w-8 mb-2" />
                  <p>Bu bölüm şu anda geliştirme aşamasındadır.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
