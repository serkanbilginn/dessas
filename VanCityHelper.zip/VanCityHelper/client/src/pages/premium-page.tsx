import { useState } from "react";
import Header from "@/components/ui/layout/header";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Star, Zap, Building, Map, Clock, CalendarRange } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import AuthPage from "./auth-page";

export default function PremiumPage() {
  const { user, upgradeToPremiumMutation } = useAuth();
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  
  const handleUpgradeToPremium = () => {
    if (!user) {
      setAuthDialogOpen(true);
      return;
    }
    
    upgradeToPremiumMutation.mutate();
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenAuthModal={() => setAuthDialogOpen(true)} />
      
      <main className="container mx-auto px-4 py-10 md:py-16">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Premium Üyelik Avantajları
          </h1>
          <p className="text-lg text-gray-600">
            İşletmenizi Van Rehberi'nde öne çıkarın ve daha fazla müşteriye ulaşın.
          </p>
        </div>
        
        {user?.isPremium ? (
          <Card className="max-w-xl mx-auto mb-12 border-2 border-primary">
            <CardHeader className="bg-blue-50 text-center">
              <CardTitle className="text-2xl text-primary">
                <div className="flex items-center justify-center gap-2">
                  <Star className="h-6 w-6 fill-yellow-400 text-yellow-400" />
                  <span>Premium Üyeliğiniz Aktif</span>
                </div>
              </CardTitle>
              <CardDescription>
                Premium üyelik özelliklerinin keyfini çıkarın.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Check className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">İşletme Listeleme</h3>
                    <p className="text-sm text-gray-600">İşletmelerinizi premium özellikler ile listeleyebilirsiniz.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Check className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">Öne Çıkan Konumlar</h3>
                    <p className="text-sm text-gray-600">İşletmeniz arama sonuçlarında üst sıralarda yer alır.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Check className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">Detaylı İstatistikler</h3>
                    <p className="text-sm text-gray-600">İşletmenizin görüntülenme ve ziyaret istatistiklerini görün.</p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button size="lg" className="w-full">
                <Building className="mr-2 h-5 w-5" />
                İşletme Ekle
              </Button>
              <p className="text-sm text-gray-500 text-center">
                İşletme ekleme sayfasına giderek hemen işletmenizi ekleyebilirsiniz.
              </p>
            </CardFooter>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card className="border border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg">Standart Üyelik</CardTitle>
                <CardDescription>Temel özellikler</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold">Ücretsiz</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mekanları arama</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Tüm kategorileri görüntüleme</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mekan detaylarını görüntüleme</span>
                  </li>
                  <li className="flex items-center opacity-50">
                    <Check className="h-5 w-5 mr-2" />
                    <span>İşletme ekleme</span>
                  </li>
                  <li className="flex items-center opacity-50">
                    <Check className="h-5 w-5 mr-2" />
                    <span>Öne çıkan listeleme</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" disabled className="w-full">
                  Mevcut Plan
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="border-2 border-primary relative">
              <div className="absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-semibold rounded-bl-lg">
                Önerilen
              </div>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 mr-2" />
                  Premium Üyelik
                </CardTitle>
                <CardDescription>Tüm özelliklere erişim</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-primary">₺149</span>
                  <span className="text-gray-500">/aylık</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mekanları arama</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Tüm kategorileri görüntüleme</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mekan detaylarını görüntüleme</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span><strong>Sınırsız işletme ekleme</strong></span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span><strong>Öne çıkan işletme listeleme</strong></span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button 
                  size="lg" 
                  className="w-full"
                  onClick={handleUpgradeToPremium}
                  disabled={upgradeToPremiumMutation.isPending}
                >
                  <Zap className="mr-2 h-5 w-5" />
                  {upgradeToPremiumMutation.isPending ? "İşleniyor..." : "Premium Ol"}
                </Button>
              </CardFooter>
            </Card>
          </div>
        )}
        
        <div className="max-w-4xl mx-auto mt-16">
          <h2 className="text-2xl font-bold text-center mb-8">Premium Üyeliğin Faydaları</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex justify-center">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Building className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-center mb-2">İşletme Listeleme</h3>
                <p className="text-sm text-center text-gray-600">
                  İşletmenizi ekleyerek Van'daki potansiyel müşterilere ulaşın ve bilinirliğinizi artırın.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex justify-center">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Map className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-center mb-2">Haritada Öne Çıkma</h3>
                <p className="text-sm text-center text-gray-600">
                  İşletmeniz haritada ve listelerde öne çıkar, daha fazla kişi tarafından görülür.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex justify-center">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-center mb-2">7/24 Görünürlük</h3>
                <p className="text-sm text-center text-gray-600">
                  İşletmeniz günün her saati Van sakinleri tarafından görülebilir ve erişilebilir olur.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="max-w-2xl mx-auto mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Sorularınız mı var?</h2>
          <p className="text-gray-600 mb-6">
            Premium üyelik hakkında daha fazla bilgi almak için bizimle iletişime geçebilirsiniz.
          </p>
          <Button variant="outline" size="lg">İletişime Geç</Button>
        </div>
      </main>
      
      {/* Auth Dialog */}
      <Dialog open={authDialogOpen} onOpenChange={setAuthDialogOpen}>
        <DialogContent className="sm:max-w-md p-0">
          <AuthPage inDialog onAuthSuccess={() => setAuthDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
