import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";

import Header from "@/components/ui/layout/header";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { Category, insertLocationSchema, Location } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MapPin, Save, Plus, MapPinned } from "lucide-react";
import { GoogleMapComponent } from "@/components/map/google-map";

// Extend the location schema to include validation
const extendedLocationSchema = insertLocationSchema.extend({
  name: z.string().min(3, "Mekan adı en az 3 karakter olmalı"),
  category: z.string().min(1, "Kategori seçmelisiniz"),
  address: z.string().min(5, "Adres en az 5 karakter olmalı"),
  phone: z.string().min(5, "Telefon numarası en az 5 karakter olmalı"),
  latitude: z.string().regex(/^-?\d+(\.\d+)?$/, "Geçerli bir enlem girin"),
  longitude: z.string().regex(/^-?\d+(\.\d+)?$/, "Geçerli bir boylam girin"),
});

type FormValues = z.infer<typeof extendedLocationSchema>;

export default function AddLocationPage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [showSuccess, setShowSuccess] = useState(false);
  const [selectedMapLocation, setSelectedMapLocation] = useState<Location | null>(null);
  const [tempMarker, setTempMarker] = useState<{lat: number, lng: number} | null>(null);
  
  // Redirect if not logged in
  if (!user) {
    navigate("/auth");
    return null;
  }
  
  // Get categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(extendedLocationSchema),
    defaultValues: {
      name: "",
      category: "",
      address: "",
      phone: "",
      description: "",
      hours: "",
      latitude: "",
      longitude: "",
      isPremium: user.isPremium ? true : false,
      images: [],
      userId: user.id
    },
  });
  
  // Create location mutation
  const createMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/locations", data);
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Mekan eklenirken bir hata oluştu");
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/locations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my/locations"] });
      setShowSuccess(true);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update form with map coordinates
  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng) {
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();
      
      // Update the form
      form.setValue("latitude", lat.toString());
      form.setValue("longitude", lng.toString());
      
      // Set temporary marker for display
      setTempMarker({ lat, lng });
      
      // Show a success message
      toast({
        title: "Konum seçildi",
        description: `Enlem: ${lat.toFixed(6)}, Boylam: ${lng.toFixed(6)}`,
      });
    }
  }, [form, toast]);
  
  const onSubmit = (data: FormValues) => {
    createMutation.mutate(data);
  };
  
  const handleClose = () => {
    setShowSuccess(false);
    navigate("/");
  };
  
  const handleAddAnother = () => {
    setShowSuccess(false);
    setTempMarker(null);
    form.reset();
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 md:py-10">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-xl md:text-2xl font-bold flex items-center gap-2">
              <Plus className="h-5 w-5" />
              İşletme Ekle
            </CardTitle>
            <CardDescription>
              Van Rehberi'ne işletmenizi ekleyerek daha fazla müşteriye ulaşın.
              {!user.isPremium && (
                <span className="block mt-2 text-amber-600">
                  Premium üye olmadığınız için işletmeniz onay sürecinden geçecektir.
                </span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>İşletme Adı</FormLabel>
                        <FormControl>
                          <Input placeholder="İşletmenizin adı" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Kategori</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Kategori seçin" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem 
                                key={category.id} 
                                value={category.name}
                              >
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Adres</FormLabel>
                      <FormControl>
                        <Textarea placeholder="İşletme adresi" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefon</FormLabel>
                      <FormControl>
                        <Input placeholder="0432 123 45 67" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="space-y-4">
                  <h3 className="text-md font-medium mb-2">İşletmenizin Konumu</h3>
                  <p className="text-sm text-gray-500 mb-3">
                    Haritada işletmenizin konumunu seçin veya koordinatları manuel olarak girin
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                    <FormField
                      control={form.control}
                      name="latitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Enlem</FormLabel>
                          <FormControl>
                            <Input placeholder="38.4944" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="longitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Boylam</FormLabel>
                          <FormControl>
                            <Input placeholder="43.3828" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="mt-4 border rounded-md overflow-hidden">
                    <div className="relative">
                      <GoogleMapComponent 
                        locations={tempMarker ? [{
                          id: -1,
                          name: "Seçilen Konum",
                          category: form.getValues("category") || "Diğer",
                          address: "",
                          phone: "",
                          description: null,
                          hours: null,
                          latitude: form.getValues("latitude") || "",
                          longitude: form.getValues("longitude") || "",
                          images: null,
                          isPremium: false,
                          createdAt: new Date(),
                          userId: user.id,
                          isApproved: true
                        }] : []}
                        height="300px"
                        interactive={true}
                        center={tempMarker ? { lat: parseFloat(form.getValues("latitude")), lng: parseFloat(form.getValues("longitude")) } : { lat: 38.494, lng: 43.380 }}
                        zoom={tempMarker ? 15 : 12}
                        onMapClick={handleMapClick}
                      />
                      {!tempMarker && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="bg-white/80 rounded-lg p-3 shadow-md">
                            <p className="text-sm text-center text-gray-600 flex items-center">
                              <MapPinned className="h-4 w-4 mr-1 text-blue-500" />
                              Harita üzerinde işletmenizin konumunu seçin
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Açıklama</FormLabel>
                        <FormControl>
                          <Textarea placeholder="İşletmeniz hakkında kısa bir açıklama" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="hours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Çalışma Saatleri</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Örn: Pazartesi-Cuma: 09:00-18:00" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {user.isPremium && (
                  <FormField
                    control={form.control}
                    name="isPremium"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Premium Listeleme</FormLabel>
                          <FormDescription>
                            İşletmeniz haritada öne çıkarılır ve arama sonuçlarında üst sıralarda gösterilir
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? (
                    "İşletme Ekleniyor..."
                  ) : (
                    <span className="flex items-center gap-2">
                      <Save className="h-4 w-4" />
                      İşletmeyi Kaydet
                    </span>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
      
      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>İşletme Başarıyla Eklendi</DialogTitle>
            <DialogDescription>
              {user.isPremium ? (
                "İşletmeniz başarıyla eklendi ve hemen yayınlandı."
              ) : (
                "İşletmeniz başarıyla eklendi ve onay sürecine alındı. Onaylandıktan sonra uygulamada görüntülenecektir."
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center py-4">
            <div className="rounded-full bg-green-100 p-4">
              <MapPin className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={handleAddAnother}>
              Başka İşletme Ekle
            </Button>
            <Button onClick={handleClose}>
              Ana Sayfaya Dön
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}