import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/ui/layout/header";
import Sidebar from "@/components/ui/layout/sidebar";
import MapContainer from "@/components/map/map-container";
import MobileNavigation from "@/components/ui/layout/mobile-navigation";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Location } from "@shared/schema";
import AuthPage from "./auth-page";

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  
  // Fetch locations
  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
  });
  
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category === selectedCategory ? undefined : category);
  };
  
  const handleLocationSelect = (location: Location) => {
    // This will be handled by the MapContainer component
  };
  
  const openAuthModal = () => {
    setAuthDialogOpen(true);
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header onOpenAuthModal={openAuthModal} />
      
      <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Sidebar (desktop only) */}
        <div className="hidden md:block">
          <Sidebar 
            onCategorySelect={handleCategorySelect}
            onLocationSelect={handleLocationSelect}
            selectedCategory={selectedCategory}
          />
        </div>
        
        {/* Map Container */}
        <MapContainer 
          locations={locations}
          selectedCategory={selectedCategory}
        />
      </main>
      
      {/* Mobile Navigation */}
      <MobileNavigation />
      
      {/* Auth Dialog */}
      <Dialog open={authDialogOpen} onOpenChange={setAuthDialogOpen}>
        <DialogContent className="sm:max-w-md p-0">
          <AuthPage inDialog onAuthSuccess={() => setAuthDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
