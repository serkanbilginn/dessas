import { useState, useCallback, useMemo, useRef } from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { Location } from '@shared/schema';

interface GoogleMapComponentProps {
  locations: Location[];
  onLocationSelect?: (location: Location) => void;
  selectedLocation?: Location | null;
  height?: string;
  center?: { lat: number, lng: number };
  zoom?: number;
  mapApiKey?: string;
  interactive?: boolean;
  onMapClick?: (e: google.maps.MapMouseEvent) => void;
}

// Default Van city coordinates
const VAN_CENTER = { lat: 38.4944, lng: 43.3828 };

const containerStyle = {
  width: '100%',
};

// Set default API key - In production, this should be an environment variable
const DEFAULT_API_KEY = 'AIzaSyA9JIfGIC18r79K-GXXkZcwSgfNO3MsTms'; // Demo key with restrictions

function getMarkerIcon(category: string, isPremium: boolean, isSelected: boolean) {
  // Color mapping based on category and premium status
  const colorMap: Record<string, string> = {
    "Eczaneler": "#1E40AF",
    "Taksi Durakları": "#EAB308",
    "Restaurantlar": "#EF4444",
    "Oteller": "#8B5CF6",
    "Marketler": "#10B981",
    "Turistik Yerler": "#3B82F6",
    "default": "#374151"
  };
  
  const color = colorMap[category] || colorMap.default;
  
  return {
    path: 'M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z',
    fillColor: color,
    fillOpacity: 1,
    strokeWeight: isSelected ? 2 : 1,
    strokeColor: '#ffffff',
    scale: isPremium ? 1.3 : 1,
    anchor: { x: 12, y: 22 },
  };
}

export function GoogleMapComponent({
  locations,
  onLocationSelect,
  selectedLocation,
  height = '70vh',
  center = VAN_CENTER,
  zoom = 13,
  mapApiKey = DEFAULT_API_KEY,
  interactive = true,
  onMapClick
}: GoogleMapComponentProps) {
  const [infoWindowOpen, setInfoWindowOpen] = useState<number | null>(null);
  const mapRef = useRef<google.maps.Map>();
  
  const containerStyleWithHeight = useMemo(() => ({
    ...containerStyle,
    height
  }), [height]);

  const onLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
  }, []);

  const onUnmount = useCallback(() => {
    mapRef.current = undefined;
  }, []);

  const handleMarkerClick = useCallback((location: Location) => {
    if (interactive) {
      setInfoWindowOpen(location.id);
      if (onLocationSelect) {
        onLocationSelect(location);
      }
    }
  }, [onLocationSelect, interactive]);

  const handleInfoWindowClose = useCallback(() => {
    setInfoWindowOpen(null);
  }, []);

  return (
    <LoadScript googleMapsApiKey={mapApiKey}>
      <GoogleMap
        mapContainerStyle={containerStyleWithHeight}
        center={center}
        zoom={zoom}
        onLoad={onLoad}
        onUnmount={onUnmount}
        onClick={onMapClick}
        options={{
          fullscreenControl: false,
          streetViewControl: false,
          mapTypeControl: false,
          zoomControl: true,
          styles: [
            {
              featureType: 'poi',
              elementType: 'labels',
              stylers: [{ visibility: 'off' }]
            }
          ]
        }}
      >
        {locations.map(location => {
          const isSelected = selectedLocation ? selectedLocation.id === location.id : false;
          const position = {
            lat: parseFloat(location.latitude),
            lng: parseFloat(location.longitude)
          };

          return (
            <Marker
              key={location.id}
              position={position}
              onClick={() => handleMarkerClick(location)}
              icon={getMarkerIcon(location.category, location.isPremium, isSelected)}
              zIndex={isSelected ? 1000 : (location.isPremium ? 100 : 1)}
            >
              {infoWindowOpen === location.id && (
                <InfoWindow onCloseClick={handleInfoWindowClose}>
                  <div className="p-2">
                    <h3 className="font-bold text-primary text-sm mb-1">{location.name}</h3>
                    <p className="text-xs text-gray-600">{location.address.split(',')[0]}</p>
                    {location.isPremium && (
                      <span className="inline-block text-xs font-semibold bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded mt-1">
                        Premium
                      </span>
                    )}
                  </div>
                </InfoWindow>
              )}
            </Marker>
          );
        })}
      </GoogleMap>
    </LoadScript>
  );
}