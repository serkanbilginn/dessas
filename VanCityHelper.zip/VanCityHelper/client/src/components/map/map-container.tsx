import { useState, useEffect } from 'react';
import { Search, Layers, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import LocationMarker from './location-marker';
import LocationDetails from './location-details';
import { Location } from '@shared/schema';

interface MapContainerProps {
  locations: Location[];
  selectedCategory?: string;
}

export default function MapContainer({ locations, selectedCategory }: MapContainerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [showLocationDetails, setShowLocationDetails] = useState(false);
  const [locationState, setLocationState] = useState<'hidden' | 'partial' | 'full'>('hidden');
  
  // Filter locations by category if selected
  const filteredLocations = selectedCategory
    ? locations.filter(location => location.category === selectedCategory)
    : locations;
  
  const handleLocationSelect = (location: Location) => {
    setSelectedLocation(location);
    setShowLocationDetails(true);
    setLocationState('full');
  };
  
  const closeLocationDetails = () => {
    setShowLocationDetails(false);
    setLocationState('hidden');
  };
  
  const getCurrentLocation = () => {
    // In a real app, this would use the Geolocation API
    alert('Konum özelliği gerçek uygulamada çalışacaktır.');
  };
  
  // Placeholder map background - in a real application, we would use Leaflet or Google Maps
  const mapBackground = "https://images.unsplash.com/photo-1569336415962-a4bd9f69c907?auto=format&q=75&fit=crop&w=1400&h=1000";
  
  return (
    <div className="flex-1 relative">
      {/* Map interface */}
      <div className="h-[calc(100vh-4rem)] bg-blue-50 relative">
        {/* Placeholder for the actual map */}
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ backgroundImage: `url('${mapBackground}')` }}
        >
          {/* This would be replaced with an actual map API integration */}
        </div>
        
        {/* Map markers */}
        {filteredLocations.map((location) => (
          <LocationMarker
            key={location.id}
            location={location}
            onClick={() => handleLocationSelect(location)}
            isActive={selectedLocation?.id === location.id}
          />
        ))}
        
        {/* Mobile search bar overlay */}
        <div className="absolute top-3 left-0 right-0 px-4 md:hidden">
          <div className="relative">
            <Input
              type="text"
              placeholder="Van'da ara..."
              className="w-full pl-10 pr-4 py-2.5 bg-white rounded-full shadow-md"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-muted-foreground" />
            </span>
          </div>
        </div>
        
        {/* Current location & filters */}
        <div className="absolute bottom-24 right-4 md:bottom-6 flex flex-col space-y-2">
          <Button 
            size="icon" 
            variant="secondary" 
            className="rounded-full shadow-md"
            title="Filtreleri Göster"
          >
            <Layers className="h-5 w-5" />
          </Button>
          <Button 
            size="icon" 
            variant="secondary" 
            className="rounded-full shadow-md"
            onClick={getCurrentLocation}
            title="Konumumu Göster"
          >
            <MapPin className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Location details bottom sheet */}
      {showLocationDetails && selectedLocation && (
        <LocationDetails
          location={selectedLocation}
          state={locationState}
          onClose={closeLocationDetails}
        />
      )}
    </div>
  );
}
