import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Location, Review, Category } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { X, MapPin, Phone, Clock, Share2, Navigation, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

interface LocationDetailsProps {
  location: Location;
  state: "hidden" | "partial" | "full";
  onClose: () => void;
}

export default function LocationDetails({ 
  location, 
  state, 
  onClose 
}: LocationDetailsProps) {
  const { user } = useAuth();
  
  // Fetch categories for icons
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch reviews for this location
  const { data: reviews = [] } = useQuery<Review[]>({
    queryKey: [`/api/locations/${location.id}/reviews`],
  });
  
  const category = categories.find(cat => cat.name === location.category);
  const iconName = category?.icon || "place";
  
  // Calculate average rating
  const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
  const averageRating = reviews.length > 0 ? totalRating / reviews.length : 0;
  
  // Default images if none provided
  const defaultImages = [
    "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&q=80&w=300&h=200&fit=crop",
    "https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&q=80&w=300&h=200&fit=crop",
    "https://images.unsplash.com/photo-1585435557343-3b092031a831?auto=format&q=80&w=300&h=200&fit=crop"
  ];
  
  const images = location.images && location.images.length > 0 
    ? location.images 
    : defaultImages;
  
  const getTimeAgo = (date: Date) => {
    try {
      const now = new Date();
      const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffInDays === 0) return "Bugün";
      if (diffInDays === 1) return "Dün";
      if (diffInDays < 7) return `${diffInDays} gün önce`;
      if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} hafta önce`;
      if (diffInDays < 365) return `${Math.floor(diffInDays / 30)} ay önce`;
      return `${Math.floor(diffInDays / 365)} yıl önce`;
    } catch (e) {
      return "Bilinmeyen tarih";
    }
  };
  
  return (
    <div 
      className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-lg bottom-sheet ${state}`}
    >
      <div className="p-4">
        {/* Handle for dragging */}
        <div className="w-12 h-1 bg-neutral-300 rounded-full mx-auto mb-4"></div>
        
        {/* Location header */}
        <div className="flex items-start">
          <div className="mr-3 mt-1">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-primary">
              <span className="material-icons">{iconName}</span>
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center">
              <h2 className="text-xl font-semibold text-neutral-800">{location.name}</h2>
              {location.isPremium && (
                <span 
                  className="ml-2 text-xs bg-yellow-400 text-white px-2 py-0.5 rounded-full"
                  title="Premium"
                >
                  Premium
                </span>
              )}
            </div>
            <p className="text-sm text-neutral-500 mt-1">{location.category}</p>
          </div>
          <button onClick={onClose} className="text-neutral-500 hover:text-neutral-700">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {/* Location photos */}
        <div className="mt-4 relative">
          <div className="flex space-x-2 overflow-x-auto py-2">
            {images.map((image, index) => (
              <img 
                key={index}
                src={image} 
                alt={`${location.name} - ${index + 1}`}
                className="rounded-lg min-w-[200px] h-32 object-cover"
              />
            ))}
          </div>
        </div>
        
        {/* Location details */}
        <div className="mt-4 space-y-3">
          <div className="flex items-center">
            <MapPin className="h-5 w-5 text-neutral-500 mr-3" />
            <p className="text-neutral-700">{location.address}</p>
          </div>
          <div className="flex items-center">
            <Phone className="h-5 w-5 text-neutral-500 mr-3" />
            <p className="text-neutral-700">{location.phone}</p>
          </div>
          <div className="flex items-center">
            <Clock className="h-5 w-5 text-neutral-500 mr-3" />
            <p className="text-neutral-700">{location.hours || "Çalışma saati bilgisi bulunamadı"}</p>
          </div>
        </div>
        
        {/* Action buttons */}
        <div className="mt-6 flex space-x-2">
          <Button 
            className="flex-1 bg-primary text-white"
            onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${parseFloat(location.latitude)},${parseFloat(location.longitude)}`, '_blank')}
          >
            <Navigation className="mr-2 h-4 w-4" />
            Yol Tarifi
          </Button>
          <Button 
            variant="outline" 
            className="flex-1 border-primary text-primary"
            onClick={() => window.open(`tel:${location.phone}`, '_blank')}
          >
            <Phone className="mr-2 h-4 w-4" />
            Ara
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="w-12 h-10"
            onClick={() => {
              const text = `${location.name} - ${location.address}`;
              const url = `https://maps.google.com/?q=${parseFloat(location.latitude)},${parseFloat(location.longitude)}`;
              if (navigator.share) {
                navigator.share({
                  title: location.name,
                  text: text,
                  url: url
                }).catch(err => console.log('Paylaşım hatası:', err));
              } else {
                // Fallback for browsers that don't support Web Share API
                navigator.clipboard.writeText(`${text}\n${url}`).then(() => {
                  alert('Adres kopyalandı!');
                }).catch(err => {
                  console.log('Kopyalama hatası:', err);
                });
              }
            }}
          >
            <Share2 className="h-5 w-5 text-neutral-500" />
          </Button>
        </div>
        
        {/* Reviews section */}
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-neutral-800">Değerlendirmeler</h3>
          <div className="flex items-center mt-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star 
                  key={star}
                  className={`h-4 w-4 ${
                    star <= Math.round(averageRating) 
                      ? "text-yellow-400 fill-yellow-400" 
                      : "text-neutral-300"
                  }`}
                />
              ))}
            </div>
            <span className="ml-2 text-neutral-700">
              {averageRating.toFixed(1)} ({reviews.length} değerlendirme)
            </span>
          </div>
          
          <div className="mt-4 space-y-4">
            {reviews.length === 0 ? (
              <p className="text-sm text-neutral-500">Henüz değerlendirme yapılmamış.</p>
            ) : (
              reviews.map((review) => (
                <div key={review.id} className="border-b border-neutral-200 pb-4">
                  <div className="flex justify-between">
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 bg-neutral-200">
                        <AvatarFallback className="text-neutral-500">
                          {review.userId.toString().substring(0, 1).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="ml-2">
                        <p className="font-medium text-neutral-800">Kullanıcı {review.userId}</p>
                        <div className="flex text-xs">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={star}
                              className={`h-3 w-3 ${
                                star <= review.rating 
                                  ? "text-yellow-400 fill-yellow-400" 
                                  : "text-neutral-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-neutral-500">
                      {getTimeAgo(review.createdAt)}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-neutral-700">{review.comment}</p>
                </div>
              ))
            )}
          </div>
          
          {/* Add review prompt if logged in */}
          {user && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-neutral-700">
                Bu mekan hakkında değerlendirme yapmak ister misiniz?
              </p>
              <Button variant="outline" className="mt-2 text-sm" size="sm">
                Değerlendirme Yap
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
