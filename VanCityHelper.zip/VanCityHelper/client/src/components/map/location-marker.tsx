import { Location } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Tooltip } from "@/components/ui/tooltip";

interface LocationMarkerProps {
  location: Location;
  onClick: () => void;
  isActive?: boolean;
}

// Generate position based on location id to spread them around
const getMarkerPosition = (id: number) => {
  // This is a placeholder function to position markers in a visually pleasing way
  // In a real application, we would use actual latitude and longitude
  const positions = [
    { top: "25%", left: "30%" },
    { top: "30%", left: "50%" },
    { top: "50%", left: "25%" },
    { top: "65%", right: "30%" },
    { top: "40%", right: "20%" },
    { top: "60%", left: "60%" },
    { top: "20%", right: "40%" },
    { top: "70%", left: "40%" }
  ];
  
  return positions[id % positions.length];
};

export default function LocationMarker({ location, onClick, isActive = false }: LocationMarkerProps) {
  // Fetch categories for icons
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const category = categories.find(cat => cat.name === location.category);
  const iconName = category?.icon || "place";
  const iconColor = category?.color || "#1E40AF";
  
  const position = getMarkerPosition(location.id);
  
  return (
    <div 
      className={`absolute location-marker ${isActive ? 'active-marker' : ''}`}
      style={{ ...position }}
      onClick={onClick}
      title={location.name}
    >
      <div className="relative">
        <span 
          className="material-icons" 
          style={{ color: iconColor }}
        >
          {iconName}
        </span>
        
        {location.isPremium && (
          <span 
            className="absolute -top-1 -right-1 text-xs bg-yellow-400 text-white rounded-full w-3 h-3 flex items-center justify-center"
            title="Premium"
          >
            <span className="material-icons text-[10px]">stars</span>
          </span>
        )}
      </div>
    </div>
  );
}
