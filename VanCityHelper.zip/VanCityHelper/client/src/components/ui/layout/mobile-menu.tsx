import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Category } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAuthModal?: () => void;
}

export default function MobileMenu({ isOpen, onClose, onOpenAuthModal }: MobileMenuProps) {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  useEffect(() => {
    // Close mobile menu when location changes
    onClose();
  }, [location, onClose]);
  
  const handleLogout = () => {
    logoutMutation.mutate();
    onClose();
  };

  return (
    <div 
      className={`fixed inset-0 bg-white z-40 transform transition-transform duration-300 ease-in-out ${
        isOpen ? "translate-x-0" : "translate-x-full"
      }`}
    >
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-neutral-200 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-primary">
              <circle cx="12" cy="12" r="10" />
              <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
            </svg>
            <h1 className="text-xl font-semibold text-primary">Van Rehberi</h1>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6 text-neutral-500" />
          </Button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {!user ? (
            <div className="flex flex-col space-y-3 mb-6">
              <Button onClick={onOpenAuthModal}>Giriş Yap</Button>
              <Button 
                variant="outline" 
                className="border-primary text-primary"
                onClick={onOpenAuthModal}
              >
                Kayıt Ol
              </Button>
            </div>
          ) : (
            <div className="border-b border-neutral-200 pb-4 mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white text-lg">
                  <span>
                    {user.fullName
                      .split(" ")
                      .map((name) => name[0])
                      .join("")
                      .toUpperCase()
                      .substring(0, 2)}
                  </span>
                </div>
                <div>
                  <h3 className="font-medium text-neutral-800">{user.fullName}</h3>
                  <p className="text-sm text-neutral-500">{user.email}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <Link href="/profile">
                  <a className="block text-neutral-800 py-2">Profil Bilgilerim</a>
                </Link>
                {user.isAdmin && (
                  <Link href="/admin">
                    <a className="block text-neutral-800 py-2">Admin Paneli</a>
                  </Link>
                )}
                <Link href="/premium">
                  <a className="block text-neutral-800 py-2">
                    {user.isPremium ? "Premium Hesabım" : "Premium Ol"}
                  </a>
                </Link>
              </div>
            </div>
          )}
          
          <h2 className="text-lg font-semibold text-neutral-800 mb-3">Kategoriler</h2>
          <div className="space-y-2 mb-6">
            {categories.map((category) => (
              <Link key={category.id} href={`/?category=${category.name}`}>
                <a className="flex items-center p-2 rounded-md hover:bg-neutral-100">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-primary mr-3">
                    <span className="material-icons text-sm">{category.icon}</span>
                  </div>
                  <span>{category.name}</span>
                </a>
              </Link>
            ))}
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-start">
              <div className="flex-shrink-0 mt-1">
                <span className="material-icons text-primary">workspace_premium</span>
              </div>
              <div className="ml-3">
                <h3 className="text-md font-medium text-neutral-800">Premium Üyelik</h3>
                <p className="text-sm text-neutral-600 mt-1">
                  İşletmenizi eklemek ve daha fazla özelliğe erişmek için premium üye olun.
                </p>
                <Link href="/premium">
                  <Button className="mt-2" size="sm">Daha Fazla Bilgi</Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-neutral-200">
          {user && (
            <Button 
              variant="ghost" 
              className="flex w-full items-center justify-center text-red-500" 
              onClick={handleLogout}
            >
              <span className="material-icons mr-2">logout</span>
              <span>Çıkış Yap</span>
            </Button>
          )}
          <div className="text-sm text-center text-neutral-500 mt-4">
            <p>© {new Date().getFullYear()} Van Rehberi • Tüm Hakları Saklıdır</p>
          </div>
        </div>
      </div>
    </div>
  );
}
