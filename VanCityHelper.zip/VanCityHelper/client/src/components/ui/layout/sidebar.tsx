import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Category, Location } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  onCategorySelect: (category: string) => void;
  onLocationSelect: (location: Location) => void;
  selectedCategory?: string;
}

export default function Sidebar({
  onCategorySelect,
  onLocationSelect,
  selectedCategory,
}: SidebarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const { user } = useAuth();
  
  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch popular locations
  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
  });
  
  // Filter locations for popular display (higher premium ones first)
  const popularLocations = [...locations]
    .sort((a, b) => (a.isPremium === b.isPremium ? 0 : a.isPremium ? -1 : 1))
    .slice(0, 3);
  
  // Get random images for locations without them
  const getRandomImage = (index: number) => {
    const images = [
      "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&q=80&w=70&h=70&fit=crop",
      "https://images.unsplash.com/photo-1643125082496-9ff26842fe6a?auto=format&q=80&w=70&h=70&fit=crop",
      "https://images.unsplash.com/photo-1525648199074-cee30ba79a4a?auto=format&q=80&w=70&h=70&fit=crop"
    ];
    return images[index % images.length];
  };
  
  const getCategoryIcon = (categoryName: string) => {
    const category = categories.find(cat => cat.name === categoryName);
    return category?.icon || "place";
  };

  return (
    <div className="w-72 bg-white shadow-md overflow-y-auto h-full">
      <div className="p-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-muted-foreground" />
          </div>
          <Input
            type="text"
            placeholder="Van'da ara..."
            className="w-full pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="mt-6">
          <h2 className="text-lg font-semibold text-neutral-800 mb-3">Kategoriler</h2>
          <div className="space-y-2">
            {categories.map((category) => (
              <div
                key={category.id}
                className={`flex items-center p-2 rounded-md hover:bg-neutral-100 cursor-pointer transition duration-200 ${
                  selectedCategory === category.name ? "bg-blue-50" : ""
                }`}
                onClick={() => onCategorySelect(category.name)}
              >
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-primary mr-3">
                  <span className="material-icons text-sm">{category.icon}</span>
                </div>
                <span>{category.name}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-6">
          <h2 className="text-lg font-semibold text-neutral-800 mb-3">Popüler Yerler</h2>
          <div className="space-y-3">
            {popularLocations.map((location, index) => (
              <Card 
                key={location.id} 
                className="hover:shadow-md transition cursor-pointer"
                onClick={() => onLocationSelect(location)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <img 
                        src={location.images?.[0] || getRandomImage(index)} 
                        alt={location.name} 
                        className="w-12 h-12 rounded-md object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-neutral-800 truncate">{location.name}</p>
                      <p className="text-xs text-neutral-500 truncate">{location.category}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        <div className="mt-6 bg-blue-50 rounded-lg p-4">
          <div className="flex items-start">
            <div className="flex-shrink-0 mt-1">
              <span className="material-icons text-primary">workspace_premium</span>
            </div>
            <div className="ml-3">
              <h3 className="text-md font-medium text-neutral-800">Premium Üyelik</h3>
              <p className="text-sm text-neutral-600 mt-1">
                İşletmenizi eklemek ve daha fazla özelliğe erişmek için premium üye olun.
              </p>
              <Link href="/premium">
                <Button className="mt-2" size="sm">
                  {user?.isPremium ? "Premium Sayfam" : "Daha Fazla Bilgi"}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
