import { Link, useLocation } from "wouter";
import { MapPin, Search, Heart, User } from "lucide-react";

export default function MobileNavigation() {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className="md:hidden bg-white shadow-lg border-t border-neutral-200">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`flex flex-col items-center p-2 ${isActive("/") ? "text-primary" : "text-neutral-500"}`}>
            <MapPin className="h-5 w-5" />
            <span className="text-xs mt-1">Keşfet</span>
          </a>
        </Link>
        <Link href="/search">
          <a className={`flex flex-col items-center p-2 ${isActive("/search") ? "text-primary" : "text-neutral-500"}`}>
            <Search className="h-5 w-5" />
            <span className="text-xs mt-1">Ara</span>
          </a>
        </Link>
        <Link href="/favorites">
          <a className={`flex flex-col items-center p-2 ${isActive("/favorites") ? "text-primary" : "text-neutral-500"}`}>
            <Heart className="h-5 w-5" />
            <span className="text-xs mt-1">Favoriler</span>
          </a>
        </Link>
        <Link href="/profile">
          <a className={`flex flex-col items-center p-2 ${
            isActive("/profile") || isActive("/auth") ? "text-primary" : "text-neutral-500"
          }`}>
            <User className="h-5 w-5" />
            <span className="text-xs mt-1">Profil</span>
          </a>
        </Link>
      </div>
    </nav>
  );
}
