import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Menu, Search, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import MobileMenu from "./mobile-menu";

interface HeaderProps {
  onOpenAuthModal?: () => void;
  onSearchClick?: () => void;
}

export default function Header({ onOpenAuthModal, onSearchClick }: HeaderProps) {
  const [location] = useLocation();
  const { user, isLoading, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const userInitials = user?.fullName
    ? user.fullName
        .split(" ")
        .map((name) => name[0])
        .join("")
        .toUpperCase()
        .substring(0, 2)
    : "";
  
  return (
    <>
      <header className="bg-white shadow-sm z-10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-primary">
              <circle cx="12" cy="12" r="10" />
              <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
            </svg>
            <Link href="/">
              <h1 className="text-xl font-semibold text-primary cursor-pointer">Van Rehberi</h1>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-muted-foreground"
              onClick={onSearchClick}
            >
              <Search className="h-4 w-4" />
              <span>Ara...</span>
            </Button>
            
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            ) : !user ? (
              <>
                <Button variant="ghost" onClick={onOpenAuthModal}>
                  Giriş Yap
                </Button>
                <Button onClick={onOpenAuthModal}>Kayıt Ol</Button>
              </>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white">
                      <span>{userInitials}</span>
                    </div>
                    <span className="hidden md:inline">{user.fullName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <Link href="/profile">Profil Bilgilerim</Link>
                  </DropdownMenuItem>
                  {user.isAdmin && (
                    <DropdownMenuItem>
                      <Link href="/admin">Admin Paneli</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem>
                    <Link href="/premium">
                      {user.isPremium ? "Premium Hesabım" : "Premium Ol"}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-red-600" onClick={handleLogout}>
                    Çıkış Yap
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden" 
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </header>
      
      <MobileMenu 
        isOpen={mobileMenuOpen} 
        onClose={() => setMobileMenuOpen(false)} 
        onOpenAuthModal={onOpenAuthModal}
      />
    </>
  );
}
